package polymorphism_5_2_1;

public interface Speaker {

	void volumUp();

	void volumDown();

}