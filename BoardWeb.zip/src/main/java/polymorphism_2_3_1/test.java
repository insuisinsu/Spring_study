package polymorphism_2_3_1;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("LL");
	}

}
